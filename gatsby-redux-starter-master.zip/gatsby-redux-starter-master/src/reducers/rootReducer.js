import { combineReducers } from 'redux';

import someReducer from './someReducer';

export default combineReducers({
  someReducer,
});
