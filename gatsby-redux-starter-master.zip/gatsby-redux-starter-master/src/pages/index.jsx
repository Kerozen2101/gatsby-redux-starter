import React from 'react';

import IndexPage from '../pagesDefinitions/Index/Index';

const Index = () => (
  <IndexPage />
);

export default Index;
